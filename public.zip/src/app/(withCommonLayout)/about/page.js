const AboutPage = () => {
  return <div>AboutPage</div>;
};

export default AboutPage;
