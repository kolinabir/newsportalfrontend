import React from "react";

const SinglePageLayout = ({ children }) => {
  return <div>{children}</div>;
};

export default SinglePageLayout;
