const UpdateNewsPage = () => {
  return <div>UpdateNewsPage</div>;
};

export default UpdateNewsPage;
