import React from 'react'

const Religion = () => {
  return (
    <div></div>
  )
}

export default Religion